export PATH="$PATH:/usr/local/bin"
