<?php
/* Icinga Web 2 | (c) 2015 Icinga Development Team | GPLv2+ */

namespace Icinga\Data;

interface SortRules
{
    /**
     * Return some sort rules
     *
     * @return  array
     */
    public function getSortRules();
}
