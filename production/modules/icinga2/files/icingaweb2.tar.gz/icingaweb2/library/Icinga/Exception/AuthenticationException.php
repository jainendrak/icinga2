<?php
/* Icinga Web 2 | (c) 2014 Icinga Development Team | GPLv2+ */

namespace Icinga\Exception;

/**
 * Exception thrown if an error occurs during authentication
 */
class AuthenticationException extends IcingaException
{
}
