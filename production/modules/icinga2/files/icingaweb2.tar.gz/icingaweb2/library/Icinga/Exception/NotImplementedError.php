<?php
/* Icinga Web 2 | (c) 2013 Icinga Development Team | GPLv2+ */

namespace Icinga\Exception;

/**
 * Class NotImplementedError
 * @package Icinga\Exception
 */
class NotImplementedError extends IcingaException
{
}
