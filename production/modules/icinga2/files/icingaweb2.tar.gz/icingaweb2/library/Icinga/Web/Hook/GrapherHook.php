<?php
/* Icinga Web 2 | (c) 2013 Icinga Development Team | GPLv2+ */

namespace Icinga\Web\Hook;

use Icinga\Application\Hook\GrapherHook as BaseHook;

/**
 * Deprecated, compat only.
 *
 * Please implement hooks in Icinga\Application\Hook
 */
abstract class GrapherHook extends BaseHook {}
