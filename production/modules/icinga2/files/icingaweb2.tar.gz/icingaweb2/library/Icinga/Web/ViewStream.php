<?php
/* Icinga Web 2 | (c) 2013 Icinga Development Team | GPLv2+ */

namespace Icinga\Web;

use Zend_View_Stream;

/**
 * Is used in Icinga\Web\View to imitate PHP's short_open_tag
 */
class ViewStream extends Zend_View_Stream
{
}
