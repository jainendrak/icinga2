<?php
/* Icinga Web 2 | (c) 2014 Icinga Development Team | GPLv2+ */

namespace Icinga\Module\Doc\Exception;

/**
 * Exception thrown if a chapter was not found
 */
class ChapterNotFoundException extends DocException
{
}
